#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Author: gaopeng
# @Date:   2018-01-22 16:44:08
# @Last modified by:   gaopeng
# @Last modified time: 2018-01-22 16:44:26

configs = {
    'db': {
        'host': '127.0.0.1'
    }
}
