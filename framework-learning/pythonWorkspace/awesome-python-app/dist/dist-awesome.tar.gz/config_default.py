#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Author: gaopeng
# @Date:   2018-01-22 16:43:16
# @Last modified by:   gaopeng
# @Last modified time: 2018-01-22 16:43:51

configs = {
    'db': {
        'host': '127.0.0.1',
        'port': 3306,
        'user': 'root',
        'password': 'root',
        'database': 'test'
    },
    'session': {
        'secret': 'AwEsOmE'
    }
}
